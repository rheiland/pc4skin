#include "ModelSourceTest.h"

int TestFunction()
{
    return 42;
}

