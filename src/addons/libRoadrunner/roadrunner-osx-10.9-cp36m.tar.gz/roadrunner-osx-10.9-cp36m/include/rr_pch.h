#ifndef rr_pchH
#define rr_pchH
//#include <windows.h>
//
//
////STD includes
#include <algorithm>
#include <cctype>
#include <deque>
#include <exception>
#include <fstream>
#include <iostream>
#include <list>
#include <limits>
#include <sstream>
#include <sstream>
#include <stack>
#include <string>
#include <vector>
#include <iomanip>
#include <ostream>
//
//#include <map>
//
//////c headers includes
//#include <cmath>
//#include <math.h>
//#include <stdio.h>
//#include <stdarg.h>
//
//#include "sbml/Model.h"
//#include "sbml/SBMLDocument.h"
//#include "rr-libstruct/lsLibStructural.h"
//
//#include "cvode/cvode.h"
//
//#include "nleq/nleq1.h"
//
//#include "rrException.h"
//#include "rrLogger.h"
//#include "rrModelFromC.h"
//#include "rrCGenerator.h"
//#include "rrUtils.h"
//#include "rrCapability.h"
//#include "rrCapabilities.h"
//#include "rrCGenerator.h"
//#include "rrCSharpGenerator.h"
//#include "rrCVODEInterface.h"
//#include "rrException.h"
//#include "rrLogger.h"
//#include "rrLogger.h"
//#include "rrObject.h"
//#include "rrRoadRunner.h"
//#include "rrRule.h"
//#include "rrScanner.h"
//#include "rrStringListContainer.h"
//#include "rrStringUtils.h"
//#include "rrStringUtils.h"
//#include "rrUtils.h"
//
//


#endif

