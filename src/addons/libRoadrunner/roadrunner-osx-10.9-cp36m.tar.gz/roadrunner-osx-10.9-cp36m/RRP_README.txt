Tellurium plugins
Copyright 2013-2014

M. T. Karlsson 1, M. Galdzicki 2  and H. M Sauro 2

1 Dune Scientific, LLC 10522 Lake City Way NE, #302 Seattle WA
2 Department of Bioengineering, University of Washington, Seattle, WA, 98195

Availability

Tellurium Plugins are licensed for free as an open source programmatic library for use in other 
applications. Its C++ API, C API, and Python APIs have comprehensive documentation. 

Acknowledgements

This work is funded by NIGMS grant: GM081070

Licence

Licensed under the Apache License, Version 2.0 (the License); you may not use this 
file except in compliance with the License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed 
under the License is distributed on an AS IS BASIS, WITHOUT WARRANTIES OR CONDITIONS 
OF ANY KIND, either express or implied. See the License for the specific language 
governing permissions and limitations under the License.

In plain english this means:

You CAN freely download and use this software, in whole or in part, for personal, 
company internal, or commercial purposes;

You CAN use the software in packages or distributions that you create.

You SHOULD include a copy of the license in any redistribution you may make;

You are NOT required include the source of software, or of any modifications you may 
have made to it, in any redistribution you may assemble that includes it.

YOU CANNOT: redistribute any piece of this software without proper attribution;
